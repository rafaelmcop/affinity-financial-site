(()=>{function remember(){for(const input of document.querySelectorAll('input[type=checkbox]'))if(/remember|trust.?device/i.test(input.name)&&!input.checked){input.checked=true;input.dispatchEvent(new Event('change',{bubbles:true}));}}remember();new MutationObserver(remember).observe(document.body,{childList:true,subtree:true});let running=false,deadline=0;const base='https://portal.fiveringsfinancial.com';function cleaned(html){const doc=new DOMParser().parseFromString(html,'text/html');doc.querySelectorAll('script,style,form,input,textarea,iframe,meta,link').forEach(x=>x.remove());doc.querySelectorAll('*').forEach(x=>{for(const a of [...x.attributes])if(a.name!=='class'&&a.name!=='href')x.removeAttribute(a.name);if(x.hasAttribute('href')){try{const u=new URL(x.getAttribute('href'),base);if(u.origin!==base||u.search||!/^\/account\/(clients|policies)(?:\/[0-9a-f-]+)?$/.test(u.pathname))x.removeAttribute('href');else x.setAttribute('href',u.href);}catch{x.removeAttribute('href');}}});return doc.body.innerHTML;}
async function read(path){
 let r,html;
 for(let attempt=0;attempt<2;attempt++){
  const remaining=deadline-Date.now();
  if(remaining<=0)throw Error('O tempo total de leitura do Five Rings terminou. Os dados já salvos foram preservados.');
  try{
   r=await fetch(base+path,{credentials:'include',signal:AbortSignal.timeout(Math.max(1,Math.min(45000,remaining))),redirect:'follow',cache:'no-store',headers:path.includes('/data?')?{'x-requested-with':'XMLHttpRequest','accept':'application/json'}:{}});
   html=await r.text();break;
  }catch(error){
   if(!/TimeoutError|AbortError/.test(String(error?.name))&&!/signal timed out|operation.*timed out/i.test(String(error?.message)))throw error;
   if(attempt===0&&deadline-Date.now()>1000)continue;
   const endpoint=new URL(base+path).pathname;
   throw Error('O Five Rings demorou para responder ao ler '+endpoint+'. A leitura não foi concluída; os dados já salvos foram preservados. Tente sincronizar novamente.');
  }
 }
 const destination=new URL(r.url),json=r.headers.get('content-type')?.includes('application/json');const doc=json?null:new DOMParser().parseFromString(html,'text/html');const loginForm=doc&&[...doc.querySelectorAll('form')].some(form=>/\/account\/login(?:$|[?#])/i.test(new URL(form.getAttribute('action')||destination.href,base).href)&&form.querySelector('input[type=password]'));const loginPage=/\/(?:login|verify|verification|challenge|captcha)(?:\/|$)/i.test(destination.pathname);if(!r.ok)throw Error('Não foi possível ler '+new URL(base+path).pathname+' no Five Rings (HTTP '+r.status+', destino '+destination.pathname+').');if(destination.origin!==base||!/^\/account(?:\/|$)/.test(destination.pathname)||loginForm||loginPage)throw Error('O Five Rings pediu autenticação na leitura de '+new URL(base+path).pathname+' (HTTP '+r.status+', destino '+destination.pathname+'). Entre no Five Rings e tente novamente.');return {body:html,contentType:json?'application/json':'text/html'};}

async function collectTable(type,nativeQuery){
 const label=type==='clients'?'clientes':'apólices',data=[],seen=new Set();let expected=null,sourceTotal=null,start=0;
 const count=value=>(typeof value==='number'||typeof value==='string'&&value.trim()!=='')&&Number.isSafeInteger(Number(value))&&Number(value)>=0?Number(value):null;
 while(start<20000){
  const params=new URLSearchParams(nativeQuery);params.set('draw',String(seen.size+1));params.set('start',String(start));params.set('length','100');params.set('search[value]','');params.set('search[regex]','false');
  const result=await read('/account/'+type+'/data?'+params);if(result.contentType!=='application/json')throw Error('Lista de '+label+' indisponível.');
  let payload;try{payload=JSON.parse(result.body);}catch{throw Error('O Five Rings retornou uma lista de '+label+' inválida.');}
  const total=count(payload.recordsTotal),filtered=payload.recordsFiltered===undefined?total:count(payload.recordsFiltered);
  if(!Array.isArray(payload.data)||total===null||filtered===null||filtered>total)throw Error('Lista de '+label+' sem contagem válida. A leitura não foi salva.');
  if(expected!==null&&(expected!==filtered||sourceTotal!==total))throw Error('A lista de '+label+' mudou durante a leitura. Sincronize novamente.');
  expected=filtered;sourceTotal=total;
  if(expected>20000)throw Error('A lista de '+label+' excede o limite seguro de 20000 registros.');
  const fingerprint=JSON.stringify(payload.data);
  if(payload.data.length&&seen.has(fingerprint))throw Error('O Five Rings repetiu uma página de '+label+'. Leitura interrompida sem salvar uma lista parcial.');
  seen.add(fingerprint);
  if(data.length+payload.data.length>expected)throw Error('A contagem de '+label+' não corresponde à lista recebida.');
  if(!payload.data.length&&data.length<expected)throw Error('Lista de '+label+' incompleta: recebidos '+data.length+' de '+expected+'. Nenhum registro desta leitura foi importado.');
  for(const row of payload.data){if(!row||typeof row!=='object')throw Error('Registro de '+label+' inválido.');data.push(Object.fromEntries(Object.entries(row).filter(([key])=>!/password|cookie|token|secret|csrf/i.test(key)).map(([key,value])=>[key,typeof value==='string'&&value.includes('<')?cleaned(value):value])));}
  if(data.length===expected)return {data,recordsTotal:sourceTotal,recordsFiltered:expected};
  // Servers may cap a page below the requested length. Advance only past rows read.
  start+=payload.data.length;
 }
 throw Error('Lista de '+label+' maior que o limite seguro do conector.');
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{if(message.action!=='collect'||running)return;running=true;deadline=Date.now()+140000;(async()=>{const pages=[],dashboard=await read('/account/dashboard');if(dashboard.contentType!=='text/html')throw Error('Painel indisponível.');if(location.origin===base&&location.pathname==='/account/dashboard'&&document.body?.innerHTML){const waitUntil=Date.now()+8000;while(!/total\s+credits/i.test(document.body.innerText||'')&&Date.now()<waitUntil)await new Promise(resolve=>setTimeout(resolve,250));dashboard.body=document.body.innerHTML;}const cleanedDashboard=cleaned(dashboard.body),email=String(message.portalEmail||'').trim().toLowerCase();if(!email||(!cleanedDashboard.toLowerCase().includes(email)&&message.manualConfirmed!==true))throw Error('Confirme que esta conta Five Rings pertence ao agente selecionado.');pages.push({url:base+'/account/dashboard',body:cleanedDashboard,contentType:'text/html'});for(const type of ['clients','policies']){const nativeQuery=message.queries?.[type];if(!nativeQuery)throw Error('Consulta nativa de '+type+' indisponível.');const table=await collectTable(type,nativeQuery);pages.push({url:base+'/account/'+type+'/data',body:JSON.stringify(table),contentType:'application/json'});}
const links=[...pages.map(p=>p.body).join(' ').matchAll(/https:\/\/portal\.fiveringsfinancial\.com\/account\/(?:clients|policies)\/[0-9a-f-]+/gi)].map(x=>x[0]);for(const link of [...new Set(links)].slice(0,60)){const detail=await read(new URL(link).pathname);if(detail.contentType!=='text/html')throw Error('Detalhe de cliente indisponível.');pages.push({url:link,body:cleaned(detail.body),contentType:'text/html'});}
return {ok:true,snapshot:{version:1,capturedAt:Date.now(),portalEmail:email,manualConfirmed:message.manualConfirmed===true,pages}};})().then(reply).catch(error=>reply({ok:false,error:error.message})).finally(()=>running=false);return true;});})();
